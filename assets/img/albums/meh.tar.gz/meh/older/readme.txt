-----------------------------------
SIMPLEVIEWER v1.8
-----------------------------------
For instructions on how to use:
http://www.airtightinteractive.com/simpleviewer/

-----------------------------------
TERMS OF USE
-----------------------------------

May be used in any kinds of personal and/or commercial projects. May not be redistributed or resold to other companies or third parties. Please ensure that the SimpleViewer download link in the bottom right corner is clearly visible.

-----------------------------------
CREDITS
-----------------------------------

Created by Airtight Interactive.
www.airtightinteractive.com
SimpleViewer � Felix Turner 2004. All rights reserved.


